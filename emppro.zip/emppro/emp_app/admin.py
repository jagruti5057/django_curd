from django.contrib import admin
from emp_app.models import emp

# Register your models here.
admin.site.register(emp)
# admin.site.register(department) 
